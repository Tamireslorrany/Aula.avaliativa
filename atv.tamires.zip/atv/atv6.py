#6

a=1
b=1
print(a)
print(b)
for i in range (3,16):
    c=a+b
    print(c)
    a=b
    b=c
