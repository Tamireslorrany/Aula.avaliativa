#10

f1=1*1
f3=3*2
f5=5*4*f3
f7=7*6*f5
f9=9*8*f7

print ("O fatorial de 1 é: %d" %f1)
print ("O fatorial de 3 é: %d" %f3)
print ("O fatorial de 5 é: %d" %f5)
print ("O fatorial de 7 é: %d" %f7)
print ("O fatorial de 9 é: %d" %f9)
