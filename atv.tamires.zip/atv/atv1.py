#1

for i in range (15,201):
    q=i**2
    print(q)
    
