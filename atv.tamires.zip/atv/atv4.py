#4

for i in range (0,200,4):
    print(i)
    
                       
