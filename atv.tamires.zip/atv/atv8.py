#8

a=1
b=1
total=0
for i in range (2,65):
    a=b
    b=b*2
    total=total+b
print (total)
