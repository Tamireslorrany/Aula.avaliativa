#5

for i in range (0,16):
    total=3**i
    print(total)
