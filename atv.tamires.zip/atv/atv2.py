#2

n=int(input("Digite um numero?"))
for i in range (1,11):
    q=i*n
    print("%dx%d=%d" %(n,i,q))
