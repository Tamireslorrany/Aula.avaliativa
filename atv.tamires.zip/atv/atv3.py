#3
total=0
for i in range(1,101):
    total=i+total
print(total)
