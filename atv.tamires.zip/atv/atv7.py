#7


for c in range (10,101,10):
    f=(9*c/5+32)
    print("%d Cº e %d Fº") %(c,f)
